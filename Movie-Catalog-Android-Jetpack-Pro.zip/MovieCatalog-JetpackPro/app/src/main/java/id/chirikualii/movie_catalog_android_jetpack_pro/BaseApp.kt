package id.chirikualii.movie_catalog_android_jetpack_pro

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

/**
 * Created by Chiriku Alii on 6/4/21.
 * github.com/chirikualii
 */

@HiltAndroidApp
class BaseApp : Application()